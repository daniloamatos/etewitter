# Django settings live in etewitter/settings.py
