from django.urls import re_path

from . import consumers

websocket_urlpatterns = [
    re_path(r'ws/messages/(?P<senderid>[\w.+]+)-(?P<receiverid>[\w.+]+)/', consumers.ChatConsumer.as_asgi()),
]