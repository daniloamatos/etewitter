
from django.contrib import admin
from django.urls import path, include, re_path
from register import views as vr
from logout import views as vlogout
from login import views as vlogin
from validations import views as vemailconf
from change import views as vchange
from django.conf import settings
from django.conf.urls.static import static
from editprofile import views as veditprofile
from userprofile import views as vuserprofile
from search import views
from main import views as viewsmain
app_name='main'

urlpatterns = [
    path('', include("main.urls")),
    path('report/', include("main.urls")),
    path('like/',include("main.urls")),
    path('save/',include("main.urls")),
    path('likereply/',include("main.urls")),
    path('notifications/', include("main.urls")),
    path('delete/', viewsmain.delete, name = 'delete'),
    path('messages/<int:senderid>-<int:receiverid>', include('chat.urls')),
    path('messages/', vuserprofile.message, name = 'message'),
    path('follow/', viewsmain.follow, name="follow"),
    path('saveditems/', viewsmain.saveditems, name="saveditems"),
    path("editprofile/", veditprofile.editprofile, name="editprofile"),
    path('register/', vr.register, name="register"),
    path('changename/', vchange.changeName, name="changeName"),
    path('changeusername/', vchange.changeUsername, name="changeUsername"),
    path('login/', vlogin.login, name='login'),
    path('forgotpass/', vlogin.forgotpass, name='forgotpass'),
    path('logout/', vlogout.logout, name='logout'),
    path('admin/', admin.site.urls),
    path('activate/<str:uidb64>/<str:token>/', vemailconf.activate, name='activate'),
    path('changepassword/', vchange.changePass, name="changePass"),
    path('confirmChange/<str:uidb64>/<str:token>/', vemailconf.confirmChange, name="confirmChange"),
    path('search/', include('search.urls')),
    path('<str:username>/',include('userprofile.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
